#!/bin/bash
# Los argumentos son guardados en variables:
PRIMERARGUMENTO=$1
ORIGEN=$2
DESTINO=$3
NOMBRE=$4
# Fechas con formato diferente, para cada uno de los casos:
DATE=`date +'%Y%m%d'`
DATE2=`date +'%H:%M:%S'`

validacion_argumentos(){

	if [ -z $PRIMERARGUMENTO ] || [ -z $ORIGEN ]  || [ -z $DESTINO ] || [ -z $NOMBRE ]; then # Línea que valida que ninguno de los argumentos obligatorios se encuentre vacía
		echo "$DATE2 - validación de argumentos | ERROR: faltan argumentos. Ej: -schedule /ruta/origen /ruta/destino nombre_backup. El backup no se realizará" >> /var/log/log_script_tp
		echo "$DATE2 - validación de argumentos | ERROR: faltan argumentos. Ej: -schedule /ruta/origen /ruta/destino nombre_backup. El backup no se realizará" 
		exit
	fi

}

validacion_destino(){
	if grep -qs $DESTINO /proc/mounts; then # El destino deberá estar montado, si lo está se encuentra en el archivo /proc/mount
		echo "$DATE2 - Validando DESTINO | Filesystem $DESTINO utilizable" >> /var/log/log_script_tp
		echo "Validando DESTINO | Filesystem $DESTINO utilizable"
        else
               	echo "$DATE2 - Validando DESTINO | ERROR: El destino $DESTINO no esta disponible o no existe. Se recomienda utilizar: /u03. El backup no se realizará" >> /var/log/log_script_tp
		echo "Validando DESTINO | ERROR: El destino $DESTINO no esta disponible o no existe. Se recomienda utilizar: /u03. El backup no se realizará"
		exit
	fi
}

validacion_origen(){
	if [ -d $ORIGEN ]; then # El origen a respaldar deberá ser un filesystem válido.
		echo "$DATE2 - Validando ORIGEN | $ORIGEN existe, se procede a realizar backup" >> /var/log/log_script_tp
		echo "Validando ORIGEN | $ORIGEN existe, se procede a realizar backup"
	elif [ -f $ORIGEN ]; then # Si el origen es un archivo, no se respaldará.
		echo "$DATE2 - Validando ORIGEN |ERROR: $ORIGEN es un archivo, solo se respaldan carpetas. El backup no se realizará" >> /var/log/log_script_tp
		echo "Validando ORIGEN |ERROR: $ORIGEN es un archivo, solo se respaldan carpetas. El backup no se realizará"
		exit
	else
		echo "$DATE2 Validando ORIGEN - ERROR: carpeta $ORIGEN no existe. El backup no se realizará" >> /var/log/log_script_tp
		echo "Validando ORIGEN - ERROR: carpeta $ORIGEN no existe. El backup no se realizará"
		exit
	fi
}

backup(){
	tar -czf $DESTINO/$NOMBRE-$DATE.tar.gz $ORIGEN >> /var/log/log_script_tp
	echo "$DATE2 - Realizando BACKUP | Se realizó backup de filesystem: $ORIGEN en $DESTINO/$NOMBRE-$DATE.tar.gz" >> /var/log/log_script_tp
	echo "$DATE2 - Realizando BACKUP | Se realizó backup de filesystem: $ORIGEN en $DESTINO/$NOMBRE-$DATE.tar.gz"
}

# case para dirigir el primer argumento del script a donde sea necesario:
case "$PRIMERARGUMENTO" in 

	-h)  # -h nos dirige al manual del script
		cat /usr/share/man/ayuda-script
		;;
	-b)  # -a es utilizado para realizar backups todos los días (all) a las 00:00 hs
		validacion_argumentos
		validacion_origen
		validacion_destino
		backup
		;;
#	-d)  # -d es utilizado para realizar backups los domingos a las 23:00 hs
#		validacion_argumentos
#		validacion_origen
#		validacion_destino
#		backup
#		;;
	*)  # Argumentos no válidos.
		echo "$DATE2 validando schedule - ERROR: Argumento principal incorrecto (-a o -d o -h). El backup no se realizará" >> /var/log/log_script_tp
		echo "Argumento principal incorrecto (-a o -d o -h) Ejemplo: -schedule /ruta/origen /ruta/destino nombre_backup"
		;;
esac 
