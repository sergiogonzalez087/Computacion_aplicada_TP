DIACONSULTA=$1

# variables de fecha
DAY=`echo $DIACONSULTA | cut -d "/" -f 1`
MONTH=`echo $DIACONSULTA | cut -d "/" -f 2`
YEAR=`echo $DIACONSULTA | cut -d "/" -f 3`
FORMATEDDAY=$YEAR-$MONTH-$DAY
DAYRESULT=`date +\%A -d $FORMATEDDAY`
DAYMONTH=$DAY-$MONTH

SEGUNDOLUNES=""
TERCERLUNES=""
CUARTOLUNES=""

TRANSFER=`cat /root/feriados.txt | grep -E ^DAYMONTH | cut -d ";" -f3`
WHY=`cat /root/feriados.txt | grep -E ^$DAYMONTH | cut -d ";" -f2 `

esLaborable(){
	cantidadCaracteres
	segundoLunesOctubre
	tercerLunesAgosto
	cuartoLunesNoviembre
	if [ $FORMATEDDAY == "$TERCERLUNES" ]; then
		echo "día $DAYRESULT $DIACONSULTA no laborable (feriado original: 17/08 - Paso a la Inmortalidad del General D. José de San Martín.)"
		echo ""
		exit 0
	elif [ $FORMATEDDAY == "$SEGUNDOLUNES" ]; then
		echo "día $DAYRESULT $DIACONSULTA no laborable (feriado original: 12/10 - Día del Respeto a la Diversidad Cultural.)"
		echo ""
		exit 0
	elif [ $FORMATEDDAY == "$CUARTOLUNES" ]; then
		echo "día $DAYRESULT $DIACONSULTA no laborable (feriado original: 20/11 - Día de la Soberanía Nacional.)"
		echo ""
		exit 0
	elif [ $DAYRESULT == "lunes" ] || [ $DAYRESULT == "martes" ] || [ $DAYRESULT == "miércoles" ] || [ $DAYRESULT == "jueves" ] || [ $DAYRESULT == "viernes" ]; then #&& [ $TRANSFER == "notransfer" ]; then

		if grep -qs $DAYMONTH /root/feriados.txt && [ "$TRANSFER" == "notransfer" ]; then
			echo ""
			echo "El día $DAYRESULT $DIACONSULTA NO es laborable."
			echo "Motivo: Feriado por $WHY "
			echo ""
		else 
			echo ""
			echo "El día $DAYRESULT $DIACONSULTA es laborable."
			echo ""
		fi
	

	elif [ $DAYRESULT == "sábado" ] || [ $DAYRESULT == "domingo" ]; then
		#if grep -qs $DAYMONTH /root/feriados.txt && [ $TRANSFER == "transfer" ]; then
			echo ""
			echo "El día $DAYRESULT $DIACONSULTA NO es laborable por ser fin de semana."
			echo ""
		#fi
	fi
}

tercerLunesAgosto(){
	MONDAYNUMBER=0
	for i in {1..30}; do
		if [ $MONDAYNUMBER != 3 ]; then
			if [ `date +\%A -d "$YEAR-08-$i" ` == "lunes" ]; then
				MONDAYNUMBER=$((MONDAYNUMBER+1))
			fi
		else
			DAYM=$(($i-1))
			TERCERLUNES=$YEAR-08-$DAYM
			break
		fi
	done
}

segundoLunesOctubre(){
	MONDAYNUMBER=0
	for i in {1..30}; do
		if [ $MONDAYNUMBER != 2 ]; then
			if [ `date +\%A -d "$YEAR-10-$i" ` == "lunes" ]; then
				MONDAYNUMBER=$((MONDAYNUMBER+1))
			fi
		else
			DAYM=$(($i-1))
			SEGUNDOLUNES=$YEAR-10-$DAYM
			break
		fi
	done
}

cuartoLunesNoviembre(){
	MONDAYNUMBER=0
	for i in {1..30}; do
		if [ $MONDAYNUMBER != 4 ]; then
			if [ `date +\%A -d "$YEAR-11-$i" ` == "lunes" ]; then
				MONDAYNUMBER=$((MONDAYNUMBER+1))
			fi
		else
			DAYM=$(($i-1))
			CUARTOLUNES=$YEAR-11-$DAYM
			break
		fi
	done
}


cantidadCaracteres(){
CANTCARACTERES=`echo ${#DAY}`
if [ $CANTCARACTERES -lt 2 ]; then
	DAY="0$DAY"
	FORMATEDDAY=$YEAR-$MONTH-$DAY
fi
CANTCARACTERES=`echo ${#MONTH}`
if [ $CANTCARACTERES -lt 2 ]; then
	MONTH="0$MONTH" 
	FORMATEDDAY=$YEAR-$MONTH-$DAY
fi
}
