#!/bin/bash
MAILTO=root
PROCESO=`ps -A | grep -m 1 $1 | sed "s/^ *//g" | cut -d " " -f 1` 	# Guardo en una variable $PROCESO el listado filtrado por un argmento, de los procesos en ejecución. Elimino los primeros espacios, guardo solo el PID


	if [ $PROCESO > 0 ]; then 					# evalúo si el PID es > a 0, entonces el proceso si está en ejecución.
		echo "el proceso $1 con PID: $PROCESO se encuentra en ejecución" 
		exit 0
	else 								# caso contrario, no está en ejecución.
		echo "El proceso $1 no se encuentra en ejecución" > /tmp/error.txt
		echo "El proceso $1 no se encuentra en ejecución"
		mail root -s "Proceso $1 no ejecutado" < /tmp/error.txt # Enviar mail a root.
		rm /tmp/error.txt
		exit 1
	fi 2>>/dev/null
