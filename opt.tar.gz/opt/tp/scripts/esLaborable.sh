DIACONSULTA=$1 # variable que guarda la consulta del usuario, en formato dd/mm/YYYY

# variables de fecha
DAY=`echo $DIACONSULTA | cut -d "/" -f 1`
MONTH=`echo $DIACONSULTA | cut -d "/" -f 2`
YEAR=`echo $DIACONSULTA | cut -d "/" -f 3`
FORMATEDDAY=$YEAR-$MONTH-$DAY # fecha formateada de forma tal que sea reconocida por "date"
DAYRESULT=`date +\%A -d $FORMATEDDAY` # día en palabras (lunes, martes, etc..)
DAYMONTH=$DAY-$MONTH # dd-mm --> Para ser ubicado en /opt/tp/scripts/files/feriados.txt

# Guardaran la fecha variable de los feriados transferibles.
SEGUNDOLUNES="" 
TERCERLUNES=""
CUARTOLUNES=""

#TRANSFER=`cat /opt/tp/scripts/files/feriados.txt | grep -E ^DAYMONTH | cut -d ";" -f3`
WHY=`cat /opt/tp/scripts/files/feriados.txt | grep -E ^$DAYMONTH | cut -d ";" -f2 `

esLaborable(){
	# llamada a funciones necesarias
	cantidadCaracteres
	segundoLunesOctubre
	tercerLunesAgosto
	cuartoLunesNoviembre

	# Primeros condicionales comparan la fecha dada con las posibles fechas variables por decreto.
	if [ $FORMATEDDAY == "$TERCERLUNES" ]; then
		echo "día $DAYRESULT $DIACONSULTA no laborable (feriado original: 17/08 - Paso a la Inmortalidad del General D. José de San Martín.)"
		echo ""
		exit 0
	elif [ $FORMATEDDAY == "$SEGUNDOLUNES" ]; then
		echo "día $DAYRESULT $DIACONSULTA no laborable (feriado original: 12/10 - Día del Respeto a la Diversidad Cultural.)"
		echo ""
		exit 0
	elif [ $FORMATEDDAY == "$CUARTOLUNES" ]; then
		echo "día $DAYRESULT $DIACONSULTA no laborable (feriado original: 20/11 - Día de la Soberanía Nacional.)"
		echo ""
		exit 0
	# Condicional que valida si es un día de semana
	elif [ $DAYRESULT == "lunes" ] || [ $DAYRESULT == "martes" ] || [ $DAYRESULT == "miércoles" ] || [ $DAYRESULT == "jueves" ] || [ $DAYRESULT == "viernes" ]; then

		if grep -qs $DAYMONTH /opt/tp/scripts/files/feriados.txt; then # Si el día de semana es un feriado, entonces indica que no es laborable, junto con el motivo.
			echo ""
			echo "El día $DAYRESULT $DIACONSULTA NO es laborable."
			echo "Motivo: Feriado por $WHY "
			echo ""
		else 
			echo ""
			echo "El día $DAYRESULT $DIACONSULTA es laborable."
			echo ""
		fi
	

	elif [ $DAYRESULT == "sábado" ] || [ $DAYRESULT == "domingo" ]; then # Condición que indica acción a tomar si es un fin de semana.
			echo ""
			echo "El día $DAYRESULT $DIACONSULTA NO es laborable por ser fin de semana."
			echo ""
	fi
}
#Funciones para guardar en variables las fechas que cambian según el año.
tercerLunesAgosto(){
	MONDAYNUMBER=0
	for i in {1..30}; do
		if [ $MONDAYNUMBER != 3 ]; then
			if [ `date +\%A -d "$YEAR-08-$i" ` == "lunes" ]; then
				MONDAYNUMBER=$((MONDAYNUMBER+1))
			fi
		else
			DAYM=$(($i-1))
			TERCERLUNES=$YEAR-08-$DAYM
			break
		fi
	done
}

segundoLunesOctubre(){
	MONDAYNUMBER=0
	for i in {1..30}; do
		if [ $MONDAYNUMBER != 2 ]; then
			if [ `date +\%A -d "$YEAR-10-$i" ` == "lunes" ]; then
				MONDAYNUMBER=$((MONDAYNUMBER+1))
			fi
		else
			DAYM=$(($i-1))
			SEGUNDOLUNES=$YEAR-10-$DAYM
			break
		fi
	done
}

cuartoLunesNoviembre(){
	MONDAYNUMBER=0
	for i in {1..30}; do
		if [ $MONDAYNUMBER != 4 ]; then
			if [ `date +\%A -d "$YEAR-11-$i" ` == "lunes" ]; then
				MONDAYNUMBER=$((MONDAYNUMBER+1))
			fi
		else
			DAYM=$(($i-1))
			CUARTOLUNES=$YEAR-11-$DAYM
			break
		fi
	done
}

# Si la cantidad de días o mes no tiene 2 digitos, entonces completa con un 0 a la izquierda.
cantidadCaracteres(){
CANTCARACTERES=`echo ${#DAY}`
if [ $CANTCARACTERES -lt 2 ]; then
	DAY="0$DAY"
	FORMATEDDAY=$YEAR-$MONTH-$DAY
fi
CANTCARACTERES=`echo ${#MONTH}`
if [ $CANTCARACTERES -lt 2 ]; then
	MONTH="0$MONTH" 
	FORMATEDDAY=$YEAR-$MONTH-$DAY
fi
}
