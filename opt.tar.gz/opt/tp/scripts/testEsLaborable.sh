#!/bin/bash
source /opt/tp/scripts/esLaborable.sh

# Entrada por argumento. fprmato dd/mm/yyyy
DIACONSULTA=$1
esLaborable $DIACONSULTA


